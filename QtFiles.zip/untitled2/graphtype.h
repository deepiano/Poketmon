#ifndef GRAPHTYPE_H
#define GRAPHTYPE_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include <QVector>
#include <iostream>
#include <algorithm>
#include <QPushButton>
#include <QLineEdit>


using namespace std;

struct NodeType
{
    int MonsterType;
    int index;
    bool operator==(NodeType rhs);

};

class GraphType : public QWidget//Qt 클래스이므로 이런 식으로 QWidget을 상속받게 해 놓았다.
{
    Q_OBJECT
public:
    explicit GraphType(QWidget *parent = 0);
    explicit GraphType(QWidget *parent=0,int n=0);
    GraphType(QWidget *parent,int** test, int n);
    ~GraphType();

    NodeType* getNodeList();
    int** getAdjmatrix();
    int getNodeCount();
    QVector<int> getAdjacent(int target);//vector를 Qt 타입인 QVector로 대체
    int WeightIs(int first, int second);
    bool IsAdjacent(int first, int second);
    bool AddToAdj(int num,int row,int col);// AdjMatrix[row][col]의 값을 num으로 설정. 다른 인접행렬 값 설정 방법을 찾으면 제거 예정.

private:
    int* nodeList;
    int** AdjMatrix;
    int nodeCount;

};

#endif // GRAPHTYPE_H
