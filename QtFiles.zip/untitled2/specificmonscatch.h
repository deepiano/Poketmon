#ifndef SPECIFICMONSCATCH_H
#define SPECIFICMONSCATCH_H
#include "selectalgorithm.h"

class SpecificMonsCatch : public SelectAlgorithm// 제한시간 내에 특정 몬스터를 가장 많이 잡는 문제를 위한 클래스.
{
public:
    SpecificMonsCatch();
    void FindRoute();
};

#endif // SPECIFICMONSCATCH_H
