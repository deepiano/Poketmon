#ifndef MANYMONSCATCH_H
#define MANYMONSCATCH_H

#include "selectalgorithm.h"
class ManyMonsCatch : public SelectAlgorithm// 제한시간 내에 가장 많은 몬스터를 잡는 문제를 위한 클래
{
public:
    ManyMonsCatch();
    void FindRoute();
};

#endif // MANYMONSCATCH_H
