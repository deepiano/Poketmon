#ifndef SELECTALGORITHM_H
#define SELECTALGORITHM_H

#include <QObject>
#include <QWidget>

class SelectAlgorithm : public QWidget// 전략패턴 구현을 위한 부모 추상클래스.
{
    Q_OBJECT
public:
    explicit SelectAlgorithm(QWidget *parent = 0);
    virtual void FindRoute()=0;//실제 구현은 자식 클래스에서!

signals:

public slots:
};

#endif // SELECTALGORITHM_H
