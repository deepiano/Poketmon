#include "manymonscatch.h"

ManyMonsCatch::ManyMonsCatch()
{

}

void ManyMonsCatch::FindRoute()
{

}
