#include "manymonscatch.h"

ManyMonsCatch::ManyMonsCatch()
{

}
