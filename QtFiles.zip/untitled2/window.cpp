#include "window.h"
#include <QString>
Window::Window(QWidget *parent) : QWidget(parent)
{
    setFixedSize(200,200);
    m_b=new QPushButton("Hi",this);
    m_b->setGeometry(10,10,80,30);
    m_b->setCheckable(true);
    connect(m_b,SIGNAL(clicked(bool)),this,SLOT(Button_Clicked(bool)));
    l_e=new QLineEdit(this);
    l_e->setGeometry(50,70,90,40);
    m_b2=new QPushButton("Reg",this);
}

  void Window::Button_clicked(bool check)
  {
      if(check)
      {
          QString qstr=QString("%1").arg(g->getAdjacent(g->getNodeList()[0])[0]);
          l_e->setText(qstr);
      }
  }
