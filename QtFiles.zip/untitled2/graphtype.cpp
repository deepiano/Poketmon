#include "graphtype.h"

GraphType::GraphType(QWidget *parent) : QWidget(parent)
{

}
bool NodeType::operator==(NodeType rhs)
{
    return this->index == rhs.index;
}
GraphType::GraphType(QWidget *parent, int n):QWidget(parent)
{
    nodeCount=n;
    AdjMatrix=new int*[n];
    for(int i=0;i<n;i++)
    {
        AdjMatrix[i]=new int[i];
    }
    nodeList=new NodeType[n];
    for(int i=0;i<n;i++)
    {
        NodeType nod;
        nod.index=i;
        nodeList[i]=nod;
    }

}

GraphType::GraphType(QWidget *parent, int **test, int n):QWidget(parent)
{
    nodeList=new NodeType[n];

    AdjMatrix=new int* [n];
    for(int i=0;i<n;i++)
    {
        AdjMatrix[i]=new int[n];
    }
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            AdjMatrix[i][j]=test[i][j];
        }
    }
    for(int i=0;i<n;i++)
    {
        nodeList[i].index=i;
    }
    nodeCount=n;
}

GraphType::~GraphType()
{

}

bool GraphType::IsAdjacent(int first, int second)
{
    QVector<int> adjFirst=getAdjacent(first);

}

int GraphType::WeightIs(int first, int second)
{
    if(first==second)
    {
        return 0;
    }
    else if(IsAdjacent(first,second))
    {
        return AdjMatrix[first][second];
    }
    else
    {
        return -1;
    }
}

NodeType* GraphType::getNodeList()
{
    return nodeList;
}

int** GraphType::getAdjmatrix()
{
    return AdjMatrix;
}

QVector<int> GraphType::getAdjacent(int target)
{
    QVector<int> toReturn;
    for(int i=0;i<nodeCount;i++)
    {
        if(AdjMatrix[target][i]!=-1&&AdjMatrix[target][i]!=0)
        {
            toReturn.push_back(i);
        }
    }
    return toReturn;
}


int GraphType::getNodeCount()
{
    return nodeCount;
}

bool GraphType::AddToAdj(int num, int row, int col)
{
    *(*(AdjMatrix+row)+col)=num;
}
