#include "selwindow.h"

SelWindow::SelWindow(QWidget* parent):QWidget(parent)
{
    setFixedSize(300,200);
}
