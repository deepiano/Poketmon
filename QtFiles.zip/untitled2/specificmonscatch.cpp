#include "specificmonscatch.h"

SpecificMonsCatch::SpecificMonsCatch()
{

}

void SpecificMonsCatch::FindRoute()
{

}
