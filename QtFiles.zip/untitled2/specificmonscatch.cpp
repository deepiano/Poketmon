#include "specificmonscatch.h"

SpecificMonsCatch::SpecificMonsCatch()
{

}
