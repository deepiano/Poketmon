#ifndef SOLVEA_H
#define SOLVEA_H

#include <QObject>
#include <QWidget>
#include "GraphType.h"
#include <iostream>
#include <QStack>
#include <QVector>


using namespace std;

struct Route
{
    QVector<NodeType> route;
    int time;
    int poketmon_counter[NUM_POKETMON];
};


class SolveA : public QWidget
{
    Q_OBJECT
public:
    explicit SolveA(QWidget *parent = 0);
    void setGraph(GraphType graph);
    QVector<Route> getSolutionA();
    void setProblemA(int specificTime, int specific_poketmon_id);

    bool promising(QVector<NodeType>& sol);
    void construct_candidates(QVector<NodeType>& sol, bool visited[], vector<int>& cand);
    void process_solution(QVector<NodeType>& sol, int time, int poketmon_counter[]);
    void backtrack(QVector<NodeType>& sol, bool visited[],
        int time, int poketmon_counter[]);
    void make_all_route();
    void find_solution();

signals:

public slots:
private:
    QVector<Route> all_routes;
    GraphType graph;
    int poketmon_counter[NUM_POKETMON];

    int specificTime;
    int specific_poketmon_id;
};

#endif // SOLVEA_H


