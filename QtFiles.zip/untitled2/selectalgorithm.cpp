#include "selectalgorithm.h"

SelectAlgorithm::SelectAlgorithm(QWidget *parent) : QWidget(parent)
{

}
