#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "graphtype.h"
#include <QDataStream>
#include <QFile>
#include <QStandardItemModel>
#include "selwindow.h"
#include "selectalgorithm.h"
#include "specificmonscatch.h"
#include "everymonscatch.h"
#include "manymonscatch.h"


using namespace std;
/*
 * MainWindow는 GUI구현에서의 기본 창이다. 현재는 여기에서 Application 클래스와 비슷한 역할도 겸하고 있다.
 * 기본 역할은 기본 창의 구현과 버튼 또는 콤보박스 등의 요소들과 연결된 함수 정의.
 * Application 클래스를 추가하게 되면 구성이 달라질 수 있다.
*/

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    GraphType* getg()
    {
        return g;// 그래프를 리턴한다.
    }

    void SelectAlg(int n);// 파라미터 값으로 문제를 풀기 위한 알고리즘을 선택한다.


private slots:

    void on_pushButton_clicked();//pushbutton1(경로 도출)이 클릭되었을 때 실행되는 함수

    void on_comboBox_activated(int index);//콤보박스가 활성화되었을 때 실행되는 함수

    void on_pushButton_2_clicked();//pushbutton2(기본 설정)이 클릭되었을 때 실행되는 함수. 알고리즘 관련 설정을 할 수 있는 별도의 팝업창이 나온다.

private:
    Ui::MainWindow *ui;
   GraphType* g;// 모든 알고리즘에 사용할 자료구조인 Graph
   void loadfile();//파일 입력 함수. 아직은 오류 해결 안됨
   SelWindow* s;// 설정 팝업창을 띄우기 위해 만든 팝업창 클래스 객체의 포인터
   SelectAlgorithm* alg;// 전략 패턴을 적용하기 위해 넣은 SelectAlgorithm 클래스의 포인터.

};

#endif // MAINWINDOW_H
