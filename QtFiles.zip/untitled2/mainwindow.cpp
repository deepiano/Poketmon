#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    g=new GraphType(parent,4);
    connect(ui->pushButton,SIGNAL(clicked()),this,SLOT(on_pushButton_clicked()));
    loadfile();
    QStandardItemModel *model=new QStandardItemModel(10,3,this);
    model->setHorizontalHeaderItem(0,new QStandardItem(QString("경로")));
    model->setHorizontalHeaderItem(1,new QStandardItem(QString("시간")));
    model->setHorizontalHeaderItem(2,new QStandardItem(QString("몬스터 수")));

    ui->tableView->setModel(model);
    s=new SelWindow;
    connect(ui->comboBox,SIGNAL(activated(int)),this,SLOT(on_comboBox_activated(int)));

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()

{
   //여기에서 모든 경로를 도출할 수 있게 만들어야 함

}


void MainWindow::loadfile()//오류 해결해야함!
{
   QFile file("D:\QtProject\build-untitled2-Desktop_Qt_5_8_0_MinGW_32bit-Debug\debug\inputArray.txt");
   file.open(QIODevice::ReadOnly|QIODevice::Text);
   QDataStream in(&file);
   while(!in.atEnd())
   {
       QString line;
       in>>line;
   }
   file.close();
}



void MainWindow::on_comboBox_activated(int index)
{
    switch(index)
    {
    case 0:
    {
        SelectAlg(0);
        break;
    }
    case 1:
    {
        SelectAlg(1);
        break;
    }
    case 2:
    {
        SelectAlg(2);
        break;
    }
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    s->show();
}

void MainWindow::SelectAlg(int n)
{
    switch(n)
    {
    case 0:
    {
        alg=new SpecificMonsCatch;
        break;
    }
    case 1:
    {
        alg=new ManyMonsCatch;
        break;
    }
    case 2:
    {
        alg=new EveryMonsCatch;
        break;
    }
    }
}
