#ifndef SELWINDOW_H
#define SELWINDOW_H

#include <QObject>
#include <QWidget>
#include <QWindow>

//팝업창을 나타내기 위한 클래스. 아직 창이 팝업되는 것까지만 구현. 설정값을 MainWindow 클래스로 넘겨주는 함수 추가 예
class SelWindow:public QWidget
{
    Q_OBJECT
public:
    explicit SelWindow(QWidget* parent=0);
signals:
private slots:
private:
    QWindow q;
};

#endif // SELWINDOW_H
