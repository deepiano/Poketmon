#include "everymonscatch.h"

EveryMonsCatch::EveryMonsCatch()
{

}
