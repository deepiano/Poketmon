#include "everymonscatch.h"

EveryMonsCatch::EveryMonsCatch()
{

}

void EveryMonsCatch::FindRoute()
{

}
