#ifndef EVERYMONSCATCH_H
#define EVERYMONSCATCH_H
#include "selectalgorithm.h"

class EveryMonsCatch : public SelectAlgorithm //SelectAlgorithm의 자식. 최소 시간으로 모든 몬스터를 잡는 알고리즘을 실행한다.
{
public:
    EveryMonsCatch();
    void FindRoute();
};

#endif // EVERYMONSCATCH_H
